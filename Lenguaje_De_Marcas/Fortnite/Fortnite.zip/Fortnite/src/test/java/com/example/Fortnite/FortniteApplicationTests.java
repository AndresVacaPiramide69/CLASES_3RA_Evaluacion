package com.example.Fortnite;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FortniteApplicationTests {

	@Test
	void contextLoads() {
	}

}
