package com.example.Fortnite.repository;

import com.example.Fortnite.classes.Idioma;
import org.springframework.data.repository.CrudRepository;

public interface IdiomaRepository extends CrudRepository <Idioma, Long>{
}
