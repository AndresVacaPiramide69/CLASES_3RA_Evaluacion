package com.example.Fortnite;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FortniteApplication {
	public static void main(String[] args) {
		SpringApplication.run(FortniteApplication.class, args);
	}
}
